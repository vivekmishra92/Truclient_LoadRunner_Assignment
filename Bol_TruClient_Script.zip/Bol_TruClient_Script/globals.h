#ifndef GLOBALS_H
#define GLOBALS_H

#include <TruClient.h>

// Only declare the function (not define it here)
int getRandomArticleIndex(void);

#endif
