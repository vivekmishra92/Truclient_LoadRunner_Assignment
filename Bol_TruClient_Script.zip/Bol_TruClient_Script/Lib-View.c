//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Library_SearchFunctions()
{
	truclient_step("1", "Function searchForWarehouse", "snapshot=SearchFunctions_1.inf");
	{
		truclient_step("1.1", "Click on Waar ben je naar op zoek? textbox", "snapshot=SearchFunctions_1.1.inf");
		truclient_step("1.2", "Type warehouse in Waar ben je naar op zoek? textbox", "snapshot=SearchFunctions_1.2.inf");
		truclient_step("1.3", "Press key Enter on Waar ben je naar op zoek? textbox", "snapshot=SearchFunctions_1.3.inf");
	}

	return 0;
}
